#      <h1 align =center>Partie 1</h1>     
------------------------------------------

##  Q1.2
pour le message bonjour tout le monde:
### avec le seuil d erreur a 0 le message recu est conforme au message envoyer

*"bonjour tout le monde ""


### seuil a 0.3 a peine  : le message est tres endommage nous avons a peine 3 lettre lisible

*"A��+a`bwj�<9/atGTM"`



### seuil a 0.5 : 2 lettre lisibe mais qui ne corresponde pas forcement au message envoyer

*"����ǿ͠�W��nã[W�"

### seuil a 1 : aucune lettre lisible , message completement errone

* "�������ߋ���ߓ�ߒ������"


##  Q1.3

### En faisant varier notre seuil de probabilité a au moins 0.002 nous avons deja certaines lettres qui ont du mal a ce dechiffrer (1 a 3 lettres)

 Soevent le coeur qu’on croyait moRt
Cécile$Sauvage
[ouvent le coeur qu’on croyait mort
N’est qu’un animal endormi ;
Un air qui souffle un peu plus fort
Va le r©veiller à demi ;
Un rameau tombant de sa branche
Le fait bojdir sur ses jarrets
Et, brillante, il voit sur les prés
Lui sourire la lune blanche.





### Qui s aggrave un peu plus en utilisant le seuil a 0.01


Souvent le coeu2 qu’fn croya�t mo�t
CécylE Sauvage

Souvent decoegR`qu’on croyait mort
N��estqu’un anim!l endormi 3
Un air qui souffle un pet pl�s fop4
Va Le réveil,er à demi ;
Un rameau tombant de sa branche
Le faht boldar sur {es jarrets
Et, jrillante, il foit sur"les prés
Lui sourire la lule blanghe`.



### Et en atteignant 0.1 de probabilité d'erreur nous avons un message totalement indechiffrable

[jevent hd cneqr Q5’on #�g�ah4 mo�t
                                   ӫ#m�M s)��qg%N
S�Uvont,le CmeU{~qu��;olcrKe�yd mgrt
Nd�Yec|#aw��u� anim%d$Und�}i/ ihuU) s���Nle GnqpMe$pltsFortV lq0råv�i�der!À femy ;
Un8r�eaT $ooR �5  e w� "xi�#he*�g fajt "k�di2 Rv� ses jarreT��t- bqi�,Anteh il��g�t sur ,aS pr¹�]uk �mq2ipa la du.mb|!nih�



##  Q1.4

- Pour décompresser le fichier avec une probabilité d'erreur de 0.000001 ça marche, nous n'avons aucune erreur.
- Pour décompresser le fichier avec une probabilité d'erreur de 0.00001 à 0.00002 ça marche 1/2 du temps, donc une décompression fonctionne et la suivante ne fonctionne pas.
- Pour décompresser le fichier avec une probabilité d'erreur de 0.00003 et supérieure, le fichier ne pourra pas se décompresser.
- Pour décompresser le fichier avec une probabilité d'erreur de 0.001 ça ne marche pas.
- Pour décompresser le fichier avec une probabilité d'erreur de 0.0001 ça ne marche pas.

Nous pouvons remarquer que pour une simple phrase, on peut aller jusqu'à une probabilité d'erreur allant jusqu'à 0.3 et avoir un message bien reçu, mais concernant un poème, dès qu'on atteint une probabilité d'erreur de 0.002, le message commence déjà à se bruité. Donc, plus le message à envoyer est long et volumineux, plus la probabilité de recevoir un message intact est faible.

##  Q1.5

- A partir du seuil de probabilité  de 0.005 l'image est toute noir

- A partir du seuil de probabilité  de 0.00001 relativement bonne
-  A partir du seuil de probabilité  de 0.00005 image visible mais les pixels sont bien decalés , on voit le 1/5e de l image d origine
- A partir du seuil de probabilité  de 0.00003 meme chose encore toute l image est visible juste nous quelsques pixels decaler au niveau du milieu
- A partir du seuil de probabilité  de 0.00002 Nous pouvons voir  que le 1/10 de l image le reste est tout noir
 Notre seuil de probabilité d’erreurs à partir duquel l’image n’est plus reconnaissable est 0.000007


##  Q1.6


- les résultats montrent que la tolérance aux erreurs varie selon le type de fichier. Les fichiers texte sont plus tolérants aux erreurs, tandis que les images sont plus sensibles.

- La longueur et la complexité du message ou du fichier affectent également la capacité à corriger les erreurs. Les messages courts peuvent être plus facilement récupérés, tandis que les fichiers plus volumineux sont plus sensibles aux erreurs.

- La probabilité critique à partir de laquelle les décompressions échouent dépend du type de fichier et de sa taille. Les fichiers compressés ont tendance à être plus sensibles aux erreurs.

- Pour une transmission de données fiable, il est important de maintenir la probabilité d'erreur à un niveau très faible, en particulier pour les fichiers sensibles tels que les archives ou les images.


#   <h1 align =center>Partie 2</h1>

-----------------------------------------------------


##  Q2.1

Pour déterminer le bit majoritaire entre 3 octet on nous aidant des fonctions logique logique vu en cours d architecture en combinant des and et or:
Pour rendre la chose claire on vas renommer l'octet 1 en A , le 2 en B  et le 3 en C
Donc notre formule seras : (A&B)|(B&C)|(A&C)

##  Q2.3  
La fonction tourne bien

##  Q2.4
la sortie de chaque octet est repeté 3x . pour le message " bonjour le monde "
BBBooonnnjjjooouuurrr   tttooouuuttt   llleee   mmmooonnndddeee

En exécutant cette commande, nous vérifions que chaque octet de la chaîne "Bonjour tout le monde" est bien triplé sur la sortie standard, confirmant ainsi le bon fonctionnement de la méthode d'encodage repeat3
| : Le symbole de pipe permet de rediriger la sortie de la commande précédente vers l'entrée de la commande suivante.




##  Q2.5
En exécutant cette commande, nous pouvons vérifier que le décodage fonctionne correctement en obtenant le résultat original "Bonjour tout le monde" sur la sortie standard. Cela confirme que le décodage a correctement inversé l'encodage effectué précédemment.

- echo "Bonjour tout le monde" | ./encode repeat3  | ./decode repeat3

- Bonjour tout le monde



##  Q2.6

 Avec la commande cat TP-Erreurs.zip | •/encode repeat3 | ./decode repeat3 › archive.zip, nous comparons  les archives créée
"archive.zip" et  "Tp-erreurs.zip"  avec la commande
- "cmp -l TP-Erreurs.zip archive.zip"
 Le terminal ne retourne rien donc les fichier sont identiques.
 Quand nous comparons deux fichiers non indentique le terminal nous retourne une suite de nombres



##  Q2.7

Nous pouvons le placer entre encode et decode.
En ajoutant cbssm après l'encodage et avant le décodage, nous simulerons le transfert des données à travers le canal, ce qui nous permettra de tester la robustesse de notre système de codage et de décodage face à des perturbations.
On a donc: cat TP-Erreurs.zip | ./encode repeat3 | ./cbssm 0  |./decode repeat3 > archiveXX.zip .
Avec p comme seuil de probabilité


## Q2.8

Avec le codage a 3 repetition  notre a archive a seuil de 0,00007 et l image de 0,00008
Le seuil d'erreur est réduit en utilisant le codage à trois répétitions car cette technique permet de détecter et de corriger les erreurs même en présence d'un bruit important.
En répétant chaque bit de données trois fois, le système peut récupérer la valeur correcte même si une des répétitions est altérée. Ainsi, le seuil d'erreur est réduit, offrant une meilleure fiabilité dans la récupération des données stockées.



#   <h1 align =center>Partie 3</h1>
-----------------------------------------------------

##  Q3.1
Apres Lecture de la documentation des des codes sur lien nous avons trouver des fonctions adequates pour resoudre notre

##  Q3.2

Apres compilation avec la commande make , tout les test se sont executer avec succes


##  Q3.3

le resultat finale etant :
0 1 1 0 0

nous avons notre codage par parité etant conforme: nous avons un nombre pair de 1 donc le resultat renvoie bien 0

#  Q3.4


# <h1 align =center> Experimentation  </h1>
---------------------------------------------------

Avec :
1. le codage par parité en deux dimensions (vu en TD) :
    -  TP-Erreurs.zip et lille.gif  elle maintient  un nombre d'erreurs résiduelles minime, ne dépassant pas plus 10 Erreurs  une solution  performante, particulièrement face à un seuil  d'erreurs faible(0.0009)

2. le codage de Hamming [7, 4, 3] :
    - TP-Erreurs.zip et lille.gif Comparer au parity2d  avec un seuil d erreur (0.0009 ) au moins nous avons un nombre considerable d erreurs

N'ayant pas tester toute les autres methodes nous pouvons dire que entre ces deux codage le parity2d est le plus apte pour corriger des erreurs dans nos fichiers
