#include <stdio.h>
#include <stdlib.h>
#include "entropy.h"
#include <math.h>




void count_occurrences(FILE *file, int counts[]){
  int c;
  int i;
  c=fgetc(file);
  for (i = 0; i < 256; i++) {
    counts[i] = 0;
  }
  while (c != EOF){
      counts[c] = counts[c] + 1;
      c = fgetc(file);
  }



}
struct file_stat entropy(int counts[]){
    struct file_stat s;
    int i;
    int taille =0;
    float sum =0;
    for (i = 0; i < 256; i++){
        taille += counts[i];
        if (counts[i] != 0){
            sum += counts[i] * log2(counts[i]);
        }
    }
    s.entropy = (float)(log2(taille) - (sum / taille));;
    s.size = taille;
    return s;
}
