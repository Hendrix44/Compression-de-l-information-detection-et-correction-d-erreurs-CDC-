# TP2 ENTROPIE


## Autheur
Kadiebwe Emmanuel

## Reponses

### Partie 1 : Notion d'entropie

1. La valeur maximal de l'entropie d'un fichier est atteinte lorsque la probabilité est équiproblable dans notre cas la probabilité est de 1/256.
Par conséquent, la valeur maximal  de l'entropie d'un fichier est de 8bit.
Elle est atteine pour un fichier qui utilise tous les caractères.

2. Formule de l'entropie : `H(f) = -∑p(s) * log₂p(s)`
    avec N =∑ns et p(s)= ns/N

   * On remplace dans la formule de l'entropie :
     H(f) = -∑(ns/N) * log₂(ns/N)
         = -∑(ns/N) * log₂(ns) + ∑(ns/N) * log₂ (N)
         = (-1/N) * ∑ns * log₂(ns) + ((log₂(N))/N) * ∑ns
         = log₂(N) - (1/N) * ∑ns * log₂(ns)

### Partie 2 : Mise en œuvre du calcul de l’entropie

7. D'après le théorème sans bruit, la taille d'un fichier codé avex un code optimal doit être au mieux de : (entropie/8)*taille
8.  cf fichier file entropy.c
  * Commande  pour afficher la sortie demander :
    ```
    Dans la racine du tp2 taper la commande:
   -  make

   - ./filentropy lib/entropy.h

    ```
    On obtiens la sortie suivante :
    `le fichier fait 1156 octets et a une entropie de 4.54 bits par octet`
    `Au mieux un codage optimal améliorerait le stockage de ce fichier de 43 %`


### Partie 3 : Expériences

pour chaque fichier on exécute les commandes , dans la racine:

> make
> ./filentropy nom_de_notre fichier



|   nom_fichier               | taille_du_fichier     |           entropie      |
|:------------------------:   |:-----------------   :|:   -------------------- :|
|    DSC00004.jpeg            |   7756926 octets       |          7.98         |            
|     TPErreurs.zip           |   35050 octets          |          7.31        |                                                 
|   Readme.md                |     2111  octets         |      4.63              |
|  ElevenLabs.mp3            | 2116127  octets          |        7.94            |
| livreUnique.php            |      607  octest         |  5.13                  |   
| alarm_beep.wav             | 83344   octest          |  3.68                  |


- Les fichiers audio comme DSC00004.jpeg et ElevenLabs.mp3 montrent une entropie relativement élevée, ce qui est attendu pour des fichiers compressés ou contenant une grande variété de données.
- En revanche, des fichiers comme Readme.md ou alarm_beep.wav présentent une entropie plus faible, ce qui peut indiquer une structure plus régulière ou une répétition de motifs.
