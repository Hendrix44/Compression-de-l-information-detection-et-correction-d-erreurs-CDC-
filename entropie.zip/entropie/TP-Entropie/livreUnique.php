<?php
echo "<style>
body{
  background-color: #f5f5dc;
  width: 90%;
  text-align: center;
}
h2{
  background-color: white;

}
h1{
  text-decoration: underline red;
}

</style>
";

 // Inclusion de la bibliothèque de fonctions :
  require("lib/BookReader.class.php");
  require("lib/FileBookReader.class.php");
  require("lib/fonctionsLivre.php");

 // Lecture  du fichier et mémorisation dans des variables PHP :
 $reader = new FileBookReader('data/livres.txt');
 $book = $reader->readBook();
 $bookHTML = bookToHTML($book);

 // inclusion de la page template :
 require('views/pageLivreUnique.php');
?>
